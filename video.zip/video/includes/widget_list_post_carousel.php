<?php class List_Post_Carousel extends WP_Widget {

	/**
	 * Sets up the widgets name etc
	 */
	public function __construct() {
		$widget_ops = array( 
			'classname' 	=> 'list_post',
			'description' 	=> 'List Post',
		);
		parent::__construct( 'List_Post_Carousel', 'List Post Carousel', $widget_ops );
	}

	/**
	 * Outputs the content of the widget
	 *
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {
		$cat_id = $instance['cat'];
		$show_count = $instance['show_count'];

		if($show_count == "" || !is_numeric($show_count)){
			$show_count = 9;
		}

		echo $args['before_widget'];

		if ( ! empty( $instance['title'] ) ) {
			$title = $instance['title'];
			if($title == ""){
				$title = get_cat_name($cat_id);
			}
			echo $args['before_title'] . '<a class="more-list-index" href="'.get_category_link($cat_id).'" title="'.get_cat_name($cat_id).'">'.$title.'</a>'. $args['after_title'];
		} ?>

		<div class="list_carousel-mid">
			<ul id="movie-carousel-mid">
            	<?php 
				$args2 = array(
					'posts_per_page'         => $show_count,
					'cat'					 => $cat_id
				);
				$query_cat = new WP_Query( $args2 );

				if ( $query_cat->have_posts() ) {
					while ( $query_cat->have_posts() ) { $query_cat->the_post(); ?>
					<li id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					    <a class="movie-item m-block" title="<?php the_title(); ?>" href="<?php the_permalink(); ?>">
					        <div class="movie-carousel-mid-item">
					        	<img src="<?php echo custom_image_size(get_the_ID(), 370, 217, true) ?>" alt="<?php the_title_attribute(); ?>">
					        	<div class="movie-carousel-mid-item-meta">
					        		<div class="movie-name-1"><?php the_title(); ?></div>
					        		<span class="ribbon"><?php the_field('quality'); ?></span>
					        	</div>
					        </div>
					    </a>
					</li>
				<?php		
					}
				}
				wp_reset_postdata(); ?>
			</ul>
			<a id="prevMid" class="prev" rel="nofollow"><span class="arrow-icon left"></span></a>
			<a id="nextMid" class="next" rel="nofollow"><span class="arrow-icon right"></span></a>
		</div>
	<?php
		echo $args['after_widget'];
	}

	/**
	 * Outputs the options form on admin
	 *
	 * @param array $instance The widget options
	 */
	public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'New title', 'text_domain' ); 
		$show_count = ! empty( $instance['show_count'] ) ? $instance['show_count'] : esc_html__( '9', 'text_domain' ); 
		$cat = ! empty( $instance['cat'] ) ? $instance['cat'] : ''; ?>
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'text_domain' ); ?></label> 
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>

		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'cat' ) ); ?>"><?php esc_attr_e( 'Category:', 'text_domain' ); ?></label> 
		<?php wp_dropdown_categories(array(
			'selected' 	=> $cat, 
			'class'		=> 'widefat',
			'name' 		=> esc_attr( $this->get_field_name( 'cat' ) ), 
			'id' 		=> esc_attr( $this->get_field_id( 'title' ) ),
			'show_count'=> true,
		)); ?>
		</p>

		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'show_count' ) ); ?>"><?php esc_attr_e( 'Show Count:', 'text_domain' ); ?></label> 
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'show_count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_count' ) ); ?>" type="text" value="<?php echo esc_attr( $show_count ); ?>">
		</p>		
		<?php 
	}

	/**
	 * Processing widget options on save
	 *
	 * @param array $new_instance The new options
	 * @param array $old_instance The previous options
	 *
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['show_count'] = ( ! empty( $new_instance['show_count'] ) ) ? strip_tags( $new_instance['show_count'] ) : '';
		$instance['cat'] = ( ! empty( $new_instance['cat'] ) ) ? strip_tags( $new_instance['cat'] ) : '';

		return $instance;
	}
}

function tbregister_widget_car() {
    register_widget( 'List_Post_Carousel' );
}
add_action( 'widgets_init', 'tbregister_widget_car' );