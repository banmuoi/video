<?php class List_Post extends WP_Widget {

	/**
	 * Sets up the widgets name etc
	 */
	public function __construct() {
		$widget_ops = array( 
			'classname' 	=> 'list_post',
			'description' 	=> 'List Post',
		);
		parent::__construct( 'List_Post', 'List Post', $widget_ops );
	}

	/**
	 * Outputs the content of the widget
	 *
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {
		$cat_id = $instance['cat'];
		$show_count = $instance['show_count'];

		if($show_count == "" || !is_numeric($show_count)){
			$show_count = 9;
		}

		echo $args['before_widget'];

		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . '<a class="more-list-index" href="'.get_category_link($cat_id).'" title="'.get_cat_name($cat_id).'">'.$instance['title'].'</a>'. $args['after_title'];
		} ?>

		<div class="last-film-box-wrapper">
			<ul class="last-film-box" id="movie-first-movie">
            	<?php 
				$args2 = array(
					'posts_per_page'         => $show_count,
					'cat'					 => $cat_id
				);
				$query_cat = new WP_Query( $args2 );

				if ( $query_cat->have_posts() ) {
					while ( $query_cat->have_posts() ) { $query_cat->the_post(); 
						get_template_part('content', 'single');
					}
				}
				wp_reset_postdata(); ?>
			</ul>
		</div>
	<?php
		echo $args['after_widget'];
	}

	/**
	 * Outputs the options form on admin
	 *
	 * @param array $instance The widget options
	 */
	public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'New title', 'text_domain' ); 
		$show_count = ! empty( $instance['show_count'] ) ? $instance['show_count'] : esc_html__( '9', 'text_domain' ); 
		$cat = ! empty( $instance['cat'] ) ? $instance['cat'] : ''; ?>
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'text_domain' ); ?></label> 
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>

		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'cat' ) ); ?>"><?php esc_attr_e( 'Category:', 'text_domain' ); ?></label> 
		<?php wp_dropdown_categories(array(
			'selected' 	=> $cat, 
			'class'		=> 'widefat',
			'name' 		=> esc_attr( $this->get_field_name( 'cat' ) ), 
			'id' 		=> esc_attr( $this->get_field_id( 'title' ) ),
			'show_count'=> true,
		)); ?>
		</p>

		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'show_count' ) ); ?>"><?php esc_attr_e( 'Show Count:', 'text_domain' ); ?></label> 
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'show_count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_count' ) ); ?>" type="text" value="<?php echo esc_attr( $show_count ); ?>">
		</p>		
		<?php 
	}

	/**
	 * Processing widget options on save
	 *
	 * @param array $new_instance The new options
	 * @param array $old_instance The previous options
	 *
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['show_count'] = ( ! empty( $new_instance['show_count'] ) ) ? strip_tags( $new_instance['show_count'] ) : '';
		$instance['cat'] = ( ! empty( $new_instance['cat'] ) ) ? strip_tags( $new_instance['cat'] ) : '';

		return $instance;
	}
}

function tbregister_widget() {
    register_widget( 'List_Post' );
}
add_action( 'widgets_init', 'tbregister_widget' );