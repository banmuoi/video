$ = jQuery;
$(document).ready(function() {
    var data_id = $('#video').attr('data-id');
    var server_id = $('#video').attr('data-sv');
    if (data_id) {
        server(data_id, server_id);
    }
    $('.icon-zoom').click(function() {
        if ($('.icon-zoom').text() == 'Zoom+') {
            $(".icon-zoom").text("Zoom-");
            $("#main-content").animate({
                "width": "92%"
            });
            $('#sidebar').css("width", "92%");
            $('#sidebar').css("float", "left");
            $('html,body').animate({
                scrollTop: $('.header-play').offset().top
            }, 'slow');
        } else {
            $(".icon-zoom").text("Zoom+");
            $('#main-content').css("width", "67%");
            $('#sidebar').css("width", "31%");
            $('#sidebar').css("float", "right");
            $('html,body').animate({
                scrollTop: $('#page').offset().top
            }, 'slow');
        }
    });
    $('#header-icon').click(function() {
        $('body').toggleClass('with-sidebar');
    });
    $('#search-icon').click(function() {
        $('body').toggleClass('search-sidebar');
    });
    jQuery("#movie-carousel-mid").carouFredSel({
        prev: '#prevMid',
        next: '#nextMid',
        auto: false,
        responsive: true,
        width: '100%',
        scroll: 2,
        items: {
            width: 250,
            height: '75%',
            visible: {
                min: 2,
                max: 4
            }
        }
    });
});

function server(id, server) {
    var id = parseInt(id);
    var url = tvideo.ajax_url;

    $('#video').addClass('loading');
    $.post(url, {
        'action': 'get_video',
        idPlay: id,
        serverPlay: server
    }, function(data) {
        $('#video').removeClass('loading').html(data);
        $('.server').removeClass('active');
        $('#server' + server).addClass('active');
    });
    return false;
}

function dlvideo(IdDownload) {
    $('#show-dl').html('<p><img src=\"'+tvideo.theme_uri+'/includes/images/loadingdl.svg\" /></p>');
    var url = tvideo.ajax_url;
    var data = {
        'action': 'download_video',
        'IdDownload': IdDownload
    };
    $.post(url, data, function(e) {
        $("#show-dl").html(e);
    });
    return false;
}

function showLoadingImage() {
    $('#page').append('<div id="effect"><div id="loading-wait">Loading please wait...</div></div>');
}

function hideLoadingImage() {
    $('#effect').remove();
    $('#loading-wait').remove();
}

function topview(object, viewID, selected) {
    showLoadingImage();
    var url = tvideo.ajax_url;
    var data = {
        'action': 'topview',
        'viewID': viewID
    };
    $.post(url, data, function(e) {
        $(object).find(".list-top-movie").html(e);
        hideLoadingImage();
    });
    $(object).find(".tabs-movie-block a").removeClass("active");
    $(selected).addClass("active");
    return false;
}
var isToutchDevice = null;
var FX_DEVICE_TOUTCH = false;
var FX_DEVICE_SMALL = false;
jQuery(document).ready(function() {
    isToutchDevice = function() {
        try {
            document.createEvent("TouchEvent");
            return true;
        } catch (e) {}
        try {
            return ('ontouchstart' in document.documentElement);
        } catch (e) {}
        return false;
    }
    if (isToutchDevice()) {
        jQuery('body').addClass("fx-device-toutch");
        FX_DEVICE_TOUTCH = true;
    } else {
        FX_DEVICE_TOUTCH = false;
    }
    try {
        if (jQuery(window).width() <= 480 || jQuery(window).height() <= 480) {
            jQuery('body').addClass("fx-device-small");
            FX_DEVICE_SMALL = true;
        } else {
            FX_DEVICE_SMALL = false;
        }
    } catch (e) {
        FX_DEVICE_SMALL = false;
    }
});
jQuery(document).ready(function() {
    try {
        if (typeof topSliderInit == "undefined" && (typeof FX_DEVICE_SMALL == "undefined" || !FX_DEVICE_SMALL || typeof FX_DEVICE_TOUTCH == "undefined" || !FX_DEVICE_TOUTCH)) {
            jQuery('#movie-carousel-top').carouFredSel({
                auto: false,
                prev: '#prevTop',
                next: '#nextTop',
            });
            window.topSliderInit = true;
            eval('console.log("topSliderInit")');
        }
    } catch (err) {
        console.error(err.message);
    }
});
var lastScrollTop = 0;
$(window).scroll(function(event) {
    var st = $(this).scrollTop();
    if (st < 0) st = 0;
    if (st > lastScrollTop && st > 46) {
        $('#header').css('top', '-46px');
    } else {
        $('#header').css('top', '0');
    }
    lastScrollTop = st;
});
// ! function javdev() {
//     try {
//         ! function cir(i) {
//             (1 !== ("" + i / i).length || 0 === a) && function() {}.constructor("debugger")(), cir(++i);
//         }(0)
//     } catch (e) {
//         setTimeout(javdev, 500)
//     }
// }()