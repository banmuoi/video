<?php
/**
 * The Template for displaying all single posts.
 *
 * @package Devion
 */
get_header(); ?>
	
	<div class="container"><div class="row">
<div class="breadcrumbs-sj">
		<?php
if ( function_exists('yoast_breadcrumb') ) {
  yoast_breadcrumb( '<p id="breadcrumbs">','</p>' );
}
?>

</div>
	<div class="col-md-8">
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
<iframe src="<?php echo get_post_meta($post->ID, 'fembed', true); ?>" scrolling="no" frameborder="0" class="openloadvideo"allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true" width="100%" height="430"></iframe>
		<?php while ( have_posts() ) : the_post(); ?>

			<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
					<div class="video-meta">
					 <?php if( function_exists('the_views')) { the_views(); } ?>
					</div>
<div class="col-video-6">
				<div class="col-video-6-1">
					<?php echo get_the_post_thumbnail( $page->ID, 'thumbnail' ); ?>
				</div>

				<div class="col-video-6-2">
	
					<div class="videotime">
					<p>Runtime : <?php echo get_post_meta($post->ID, 'videotime', true); ?> min </p>
					</div>
					<div class="codevideo">
					<p>Code : <?php echo get_post_meta($post->ID, 'codevideo', true); ?> </p>
					</div>
					<div class="the-loai">
					<p>Genre : <?php echo get_the_term_list( $post->ID, 'genre', ' ', ', ', '' ); ?>   </p>
					</div>
					<div class="idol">  
					<p>Actress : <?php echo get_the_term_list( $post->ID, 'model', ' ', ', ', '' ); ?> </p>
					</div>	

					<div class="videoquality">
					<p>Quality : <?php echo get_post_meta($post->ID, 'videoquality', true); ?> </p>
					</div>
				</div>
</div>
			<?php get_template_part( 'content', 'video' ); ?>


		<?php endwhile; // end of the loop. ?>

		</main><!-- #main -->

</div>


</div><!-- #primary -->


<?php get_sidebar(); ?>

</div></div>
<div class="container">

	<div class="resj">

				<?php get_template_part( 'inc/related-videos' ); ?>
</div>
</div>
<?php get_footer(); ?>